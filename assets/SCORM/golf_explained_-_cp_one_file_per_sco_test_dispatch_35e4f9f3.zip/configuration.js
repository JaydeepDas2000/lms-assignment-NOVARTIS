DispatchRoot='https://cloud.scorm.com/ScormEngineInterface/dispatch/';
ContentURL='https://cloud.scorm.com/EngineWebServices/api/cloud/dispatch/launch?dispatchId=35e4f9f3-889c-4d6d-97dd-670f8edeadd6&launchtoken=pTscxmT41mYFr9h71YTThmtfef7oiqef3DVjVcbu&learnerid=LEARNER_ID&fname=LEARNER_FNAME&lname=LEARNER_LNAME&referringurl=REFERRING_URL&pipeurl=PIPE_URL&redirecturl=REDIRECT_URL&cssurl=CSS_URL_REGISTRATION_ARGUMENT';
DefaultCssUrl='https://app.cloud.scorm.com/sc/css/cloudPlayer/legacy-min.css';
DispatchVersion=2;
TcapiEndpoint='https://cloud.scorm.com/ScormEngineInterface/TCAPI/KQ0N0AGR3U';
PreLaunchConfigurationURL='https://cloud.scorm.com/EngineWebServices/api/cloud/dispatch/launch/config?dispatchId=35e4f9f3-889c-4d6d-97dd-670f8edeadd6&launchtoken=pTscxmT41mYFr9h71YTThmtfef7oiqef3DVjVcbu';
